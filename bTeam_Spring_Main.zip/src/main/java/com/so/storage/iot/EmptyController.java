package com.so.storage.iot;

public class EmptyController {

}
